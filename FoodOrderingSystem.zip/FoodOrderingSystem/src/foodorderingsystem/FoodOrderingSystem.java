/*
Challenge 4: Build a food ordering system where the user inputs the food name into the food order and then the order gets
passed to the appropriate restaurant on a list and the restaurant prints the receipt on stdout. No need to create a
UI, a main function that receives parameters is enough.
 */
package foodorderingsystem;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Shivani Patel
 */
public class FoodOrderingSystem {
    
    public static void main(String[] args) {
        ArrayList<String> foodType = new ArrayList<String>(); // Created arraylist to store restuarant's names
        foodType.add("Pizza");
        foodType.add("Burger");
        foodType.add("Sushi");
        foodType.add("Mexican");
        foodType.add("Pasta");
        foodType.add("Bread");
        
        System.out.println("Please select the food category from the list: \n" + foodType);
        Scanner myObj = new Scanner(System.in);
        System.out.println("\nPlease enter a food item: ");
        
        String stringInput = myObj.nextLine();
        
        String foodCategory = getFoodCategory(stringInput);
        printOrderReceipt(foodCategory, stringInput);
        
    }
    // Function to categorise food from given list
    public static String getFoodCategory(String foodItem) {
        String foodCategory;
        // Regex pattern to compare food category
        Pattern pattern = Pattern.compile("pizza|burger|sushi|mexican|pasta|bread", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(foodItem);
        boolean matchFound = matcher.find();
        
        if (matchFound == false) {
            System.out.println("\nFood Category Not found!\n");
            main(null);
            System.exit(0);
        }
        
        foodCategory = matcher.group();
        return foodCategory;
    }
    
    // To print order receipt according to restaurant and food selected
    public static void printOrderReceipt(String foodCategory, String foodItem) {
        
        switch (foodCategory.toUpperCase()) {
            case "PIZZA":
                System.out.println("Crust Pizza Restaurant, " + foodItem + ", $20");
                break;
            case "BURGER":
                System.out.println("Sam Burger Restaurant, " + foodItem + ", $15");
                break;
            case "SUSHI":
                System.out.println("Susan Sushi Food, " + foodItem + ", $18");
                break;
            case "MEXICAN":
                System.out.println("GYG Mexican Restaurant, " + foodItem + ", $16");
                break;
            case "PASTA":
                System.out.println("Italiano Pasta Restaurant, " + foodItem + ", $25");
                break;
            case "BREAD":
                System.out.println("Baker's Bread, " + foodItem + ", $8");
                break;
            default:
                System.out.println("Please enter food item with appropriate food category");
        }
        
    }
    
}
