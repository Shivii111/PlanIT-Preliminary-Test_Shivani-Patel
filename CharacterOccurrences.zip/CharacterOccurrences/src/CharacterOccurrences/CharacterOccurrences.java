/*
Challenge 2: Write a solution to find the character that has the highest number of occurrences within a certain string, ignoring
case. If there is more than one character with equal highest occurrences, return the character that appeared first
within the string.
 */
package CharacterOccurrences;

import java.util.Scanner;

/**
 *
 * @author Shivani Patel
 */
public class CharacterOccurrences {

    public static void main(String[] args) {
        //Taking user input
        Scanner myObj = new Scanner(System.in);
        System.out.println("Please enter a string: ");

        String stringInput = myObj.nextLine();
        
        //Printing Character with highest occurrences
        System.out.println("Character with highest occurrences is: " + getUniquesChar(stringInput));

    }
    static final int ASCII_SIZE = 256;

    public static char getUniquesChar(String str) {

        int count[] = new int[ASCII_SIZE];

        // Created character count array from user input string
        int len = str.length();
        for (int i = 0; i < len; i++) {

            count[str.charAt(i)]++;

        }

        int max = -1;  // Initialized max count variable
        char result = ' ';   // Initialized result variable

        // Traversing through the string & maintaining the count of each character in the string
        for (int i = 0; i < len; i++) {
            if (max < count[str.charAt(i)]) {
                max = count[str.charAt(i)];
                result = str.charAt(i);
            }
        }

        return result;
    }

}
