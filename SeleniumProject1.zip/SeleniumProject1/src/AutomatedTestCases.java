import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class AutomatedTestCases {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shivani\\Music\\App SetUp\\chromedriver_win32\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();

		String URL="https://jupiter.cloud.planittesting.com/#/";
		driver.get(URL);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		//----------------------Testcase1:Is system throwing an error for incorrect login.--------------------------

		driver.findElement(By.xpath("//a[text()='Login']")).click();
		driver.findElement(By.id("loginUserName")).sendKeys("ShivaniPatel");
		driver.findElement(By.id("loginPassword")).sendKeys("vdhfbsdhfd");
		driver.findElement(By.xpath("//button[text()='Login']")).click();
		String loginError= driver.findElement(By.id("login-error")).getText();
		Assert.assertEquals(loginError, "Your login details are incorrect");
		System.out.println("Login Incorrect, Testcase 1 passed");
		driver.findElement(By.xpath("//button[text()='Cancel']")).click();

		//------------------------------Testcase2: Product buying scenario--> navigation through shopping button, shopping page, item selection, cart page, checkout page, form fill up, and placing the order.------------------
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("a.btn-success")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("(//a[@ng-click='add(item)'])[1]")).click();
		driver.findElement(By.xpath("//a[@href='#/cart']")).click();
		driver.findElement(By.xpath("//*[text()='Check Out']")).click();

		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input#forename")).sendKeys("Shivani");
		driver.findElement(By.cssSelector("input#surname")).sendKeys("Patel");
		driver.findElement(By.cssSelector("input#email")).sendKeys("123@gmail.com");
		driver.findElement(By.cssSelector("input#telephone")).sendKeys("0123456789");
		driver.findElement(By.cssSelector("textarea#address")).sendKeys("1,ABC Road, VIC");

		Select se = new Select(driver.findElement(By.cssSelector("select#cardType")));
		se.selectByValue("Visa");

		driver.findElement(By.cssSelector("input#card")).sendKeys("1212131314141515");
		driver.findElement(By.cssSelector("button#checkout-submit-btn")).click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.alert-success")));
		String alertSuccess= driver.findElement(By.cssSelector("div.alert-success")).getText();

		driver.findElement(By.xpath("//a[text()=\"Shopping Again »\"]")).click();

		if(alertSuccess.contains("your order has been accepted")) {
			System.out.println("Order placed successfully, Testcase 2 passed");
		}else {
			System.out.println("Order has not been placed successfully, Testcase 2 failed");
		}


		//---------------------------------Testcase3:Are logo Icon and navigation bar tabs working as desired: Home, Shop, Contact tabs?----------------------------------------------------------------

		driver.findElement(By.xpath("//a[@href='#/contact']")).click();
		Assert.assertEquals(driver.getCurrentUrl(), "https://jupiter.cloud.planittesting.com/#/contact");


		driver.findElement(By.xpath("//a[@href='#/home']")).click();
		Assert.assertEquals(driver.getCurrentUrl(), "https://jupiter.cloud.planittesting.com/#/home");

		driver.findElement(By.xpath("//a[text()='Shop']")).click();
		Assert.assertEquals(driver.getCurrentUrl(), "https://jupiter.cloud.planittesting.com/#/shop");

		Thread.sleep(1000);
		driver.findElement(By.cssSelector("a.brand")).click();		
		Assert.assertEquals(driver.getCurrentUrl(), "https://jupiter.cloud.planittesting.com/#/");

		System.out.println("Navigation tabs and logo icon working properly, Testcase 3 passed");

		//-----------------------------------Testcase3: Contact tab functionality testing --> Fill the contact details and click submit button should display the thank you message on screen----------------------------------------------------------

		driver.findElement(By.xpath("//a[@href='#/contact']")).click();
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("input#forename")).sendKeys("Shivani");
		driver.findElement(By.cssSelector("input#surname")).sendKeys("Patel");
		driver.findElement(By.cssSelector("input#email")).sendKeys("123@gmail.com");
		driver.findElement(By.cssSelector("input#telephone")).sendKeys("0123456789");
		driver.findElement(By.cssSelector("textarea#message")).sendKeys("Hello Jupiter Toys!!!");
		driver.findElement(By.cssSelector("a.btn-contact")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.alert-success")));
		String alertFeedback= driver.findElement(By.cssSelector("div.alert-success")).getText();
		if(alertFeedback.contains("we appreciate your feedback")) {
			System.out.println("Feedback sent successfully, Testcase 4 passed");
		} else {
			System.out.println("Feedback has not been sent successfully, Testcase 4 failed");
		}

		driver.findElement(By.xpath("//a[@href='#/home']")).click();


		//--------------------------------------Testcase5: Is system asking the user for confirmation to empty the cart. If user select YES option, then it should empty the cart and display the empty cart message on the screen. If user clicks NO to empty cart confirmation, then it should redirect to Cart webpage-----------------------------------------------------------------


		driver.findElement(By.cssSelector("a.btn-success")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("(//a[@ng-click='add(item)'])[1]")).click();
		driver.findElement(By.xpath("(//a[@ng-click='add(item)'])[1]")).click();
		driver.findElement(By.xpath("//a[@href='#/cart']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//a[text()='Empty Cart']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//a[@ng-click='cancel()']")).click();
		Thread.sleep(1000);
		Assert.assertEquals(driver.getCurrentUrl(), "https://jupiter.cloud.planittesting.com/#/cart");

		driver.findElement(By.xpath("//a[text()='Empty Cart']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//a[@ng-click='empty()']")).click();
		Thread.sleep(1000);

		Assert.assertEquals(driver.findElement(By.cssSelector("div.alert")).getText(), "×\nYour cart is empty - there's nothing to see here.");

		System.out.println("Cart is empty now, Testcase 5 passed");

		driver.findElement(By.xpath("//a[@href='#/home']")).click();

		//--------------------------------------Testcase6: Can user modify the purchased items from the cart and does system update the price accordingly?-----------------------------------------------------------------

		driver.findElement(By.cssSelector("a.btn-success")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("(//a[@ng-click='add(item)'])[1]")).click();
		driver.findElement(By.xpath("//a[@href='#/cart']")).click();
		Thread.sleep(1000);

		String priceString= driver.findElement(By.xpath("(//td[@class='ng-binding'][2])")).getText();
		priceString= priceString.replace('$',' ');

		float price= Float.parseFloat(priceString);
		String qtyToAdd="1";
		driver.findElement(By.xpath("//input[@name='quantity']")).sendKeys(qtyToAdd);		

		int qty=Integer.parseInt(driver.findElement(By.xpath("//input[@name='quantity']")).getAttribute("value"));			
		String total= driver.findElement(By.cssSelector("strong.total")).getText();
		total = total.replace("Total: ", "");

		Assert.assertEquals(Float.parseFloat(total), countTotal(qty, price));
		System.out.println("Items modified, Testcase 6 passed");

		driver.findElement(By.xpath("//a[@href='#/home']")).click();

		//--------------------------------------Testcase7: If user click on Remove item button [RED button on the right-hand side of the item], then it should remove the item from the list-----------------------------------------------------------------

		driver.findElement(By.cssSelector("a.btn-success")).click();
		Thread.sleep(1000);

		driver.findElement(By.xpath("(//a[@ng-click='add(item)'])[1]")).click();
		driver.findElement(By.xpath("(//a[@ng-click='add(item)'])[1]")).click();			
		driver.findElement(By.xpath("(//a[@ng-click='add(item)'])[2]")).click();
		driver.findElement(By.xpath("(//a[@ng-click='add(item)'])[3]")).click();
		driver.findElement(By.xpath("//a[@href='#/cart']")).click();

		Thread.sleep(1000);
		List<WebElement> rowsBefore= driver.findElements(By.xpath("//table/tbody/tr"));
		int numOfRowsBefore= rowsBefore.size();

		driver.findElement(By.cssSelector("a.remove-item")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//a[@ng-click='removeItem(item)']")).click();
		Thread.sleep(1000);
		List<WebElement> rowsAfter= driver.findElements(By.xpath("//table/tbody/tr"));
		int numOfRowsAfter= rowsAfter.size();

		if(numOfRowsAfter>0) {
			if(numOfRowsAfter<numOfRowsBefore) {
				System.out.println("Item removed! "+numOfRowsAfter + " Item left in the cart, Testcase 7 passed");
			}
		}

		//--------------------------------------Testcase8: If any field remains blank on the checkout form and a submit button gets clicked, then it should generate validation alert message-----------------------------------------------------------------

		driver.findElement(By.xpath("//*[text()='Check Out']")).click();

		Thread.sleep(1000);
		driver.findElement(By.cssSelector("input#forename")).sendKeys("");
		driver.findElement(By.cssSelector("input#surname")).sendKeys("");
		driver.findElement(By.cssSelector("input#email")).sendKeys("");
		driver.findElement(By.cssSelector("input#telephone")).sendKeys("");
		driver.findElement(By.cssSelector("textarea#address")).sendKeys("");
		driver.findElement(By.cssSelector("input#card")).sendKeys("");
		driver.findElement(By.cssSelector("button#checkout-submit-btn")).click();

		Thread.sleep(1000);
		Assert.assertEquals(driver.findElement(By.xpath("//div[@class='alert alert-error ng-scope']")).getText(), "Almost there - but we can't send your items unless you complete the form correctly.");
		System.out.println("Please enter required value in checkout form!, Testcase 8 passed");
		//--------------------------------------Testcase9:If any field remains blank on the contact detail form and a submit button gets clicked, then it should generate validation alert message-----------------------------------------------------------------

		driver.findElement(By.xpath("//a[@href='#/contact']")).click();

		Thread.sleep(1000);
		driver.findElement(By.cssSelector("input#forename")).sendKeys("");
		driver.findElement(By.cssSelector("input#surname")).sendKeys("");
		driver.findElement(By.cssSelector("input#email")).sendKeys("");
		driver.findElement(By.cssSelector("input#telephone")).sendKeys("");
		driver.findElement(By.cssSelector("textarea#message")).sendKeys("");
		driver.findElement(By.cssSelector("a.btn-contact")).click();

		Thread.sleep(1000);
		Assert.assertEquals(driver.findElement(By.xpath("//div[@class='alert alert-error ng-scope']")).getText(), "We welcome your feedback - but we won't get it unless you complete the form correctly.");
		System.out.println("Please enter required value in contact detail form!, Testcase 9 passed");
		//--------------------------------------Testcase10: If user enters any invalid input to the given fields in contact details form, it should generation validation message-----------------------------------------------------------------

		driver.findElement(By.xpath("//a[@href='#/contact']")).click();

		Thread.sleep(1000);
		driver.findElement(By.cssSelector("input#forename")).sendKeys("");
		driver.findElement(By.cssSelector("input#surname")).sendKeys("");
		driver.findElement(By.cssSelector("input#email")).sendKeys("Shivii_");
		driver.findElement(By.cssSelector("input#telephone")).sendKeys("abcd");
		driver.findElement(By.cssSelector("textarea#message")).sendKeys("");
		driver.findElement(By.cssSelector("a.btn-contact")).click();

		Assert.assertEquals(driver.findElement(By.id("email-err")).getText(), "Please enter a valid email");
		Assert.assertEquals(driver.findElement(By.id("telephone-err")).getText(), "Please enter a valid telephone number");

		System.out.println("Please enter valid values in contact detail form, Testcase 10 passed");

		driver.quit(); // Quit from the browser

	}
	//function for counting the total price based on quantity of items and price per unit
	public static float countTotal(int qty, float price) {
		float total;
		total= qty * price;
		return total;
	}
}


